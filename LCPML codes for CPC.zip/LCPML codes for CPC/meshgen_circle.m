function meshstr = meshgen_circle(radiuspml,delh,Nlayer,scx,scy)
% Mesh generation function for Circle using triangular elements
% Called in fem.m and fempar.m
%
% Copyright (C) 2022, Ozlem Ozgun
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%    
% Contact:
% Dr. Ozlem Ozgun
% email: ozgunozlem@gmail.com
% web: http://www.ee.hacettepe.edu.tr/~ozlem/

%% ************************************************************************
% Definition of input parameters
% ************************************************************************
object = 'circle';
plot_mesh = 0;

pmldim = Nlayer*delh;  % PML distance away from the scatterer
radiusvoi = radiuspml+pmldim; 

radiussc = 2*delh; % region around source

radiuspmlx = radiuspml; radiuspmly = radiuspml;
radiusvoix = radiusvoi; radiusvoiy = radiusvoi;


%% *************************************************************************
% Boundary of circle for source
% *************************************************************************
alfac = 2*asin(delh*0.5/radiussc);
N = floor(1*pi/alfac);
Ni = 0:N;
alfai = 1*pi/N;
alfa = cat(2, alfai*Ni, -fliplr(alfai*Ni(2:end-1)));

sourceb_x = radiussc*cos(alfa) + scx;
sourceb_y = radiussc*sin(alfa) + scy;

%% ************************************************************************
% Outside of circle & Boundary of VOI
% *************************************************************************
xcoord = []; ycoord = [];

np = round(radiuspml/delh);
radiusarr = linspace(delh, radiuspml, np);
radiusarr = [radiusarr linspace(radiuspml+delh, radiusvoi, Nlayer)];

for i = 1:length(radiusarr)
    r = radiusarr(i);
    
    P = 2*pi*r / 4; % 1/4 of perimeter
    N = round(P/delh);
    th = linspace(0, pi/2, N+1);
    xquad = r*cos(th);
    yquad = r*sin(th);
    
    xupper = [xquad -fliplr(xquad(1:end-1))];
    yupper = [yquad fliplr(yquad(1:end-1))];
    xlower = [fliplr(xupper(2:end-1))];
    ylower = [-fliplr(yupper(2:end-1))];
    
    tempx = [xupper xlower];
    tempy = [yupper ylower];
    
    voib_x = tempx;
    voib_y = tempy;
    
    xcoord = cat(2, xcoord, tempx);
    ycoord = cat(2, ycoord, tempy);
    
    if ((r < radiuspml+1e-8) & (r > radiuspml-1e-8))
        pmlb_x = tempx;
        pmlb_y = tempy;
    end
end

xcoord = cat(2, xcoord, 0);
ycoord = cat(2, ycoord, 0);

%%
threshold = delh * 0.8;
[discard,d] = knnsearch([xcoord' ycoord'],[sourceb_x' sourceb_y'],'k',40);
ind = find(d < threshold);
discard = unique(discard(ind));

nodes0 = 1:length(xcoord);
nodes0(discard) = 0;
nondiscard = find(nodes0 ~= 0);

xcoord = xcoord(nondiscard);
ycoord = ycoord(nondiscard);

xcoord = cat(2, xcoord, sourceb_x);
ycoord = cat(2, ycoord, sourceb_y);

%% ************************************************************************
% Create mesh
% *************************************************************************
conn = delaunay(xcoord, ycoord);

center_x = (xcoord(conn(:,1)) + xcoord(conn(:,2)) + xcoord(conn(:,3)))/3;
center_y = (ycoord(conn(:,1)) + ycoord(conn(:,2)) + ycoord(conn(:,3)))/3;

INPO = inpolygon(center_x, center_y, sourceb_x, sourceb_y);
discard_elm = find(INPO == 1);

elms0 = 1:size(conn,1);
elms0(discard_elm) = 0;
nondiscard_elm = find(elms0 ~= 0);

conn = conn(nondiscard_elm,:);

nodes = 1:length(xcoord);
nodes(conn(:,1)) = 0;
nodes(conn(:,2)) = 0;
nodes(conn(:,3)) = 0;
nondiscard_node = find(nodes == 0);
discard_node = find(nodes ~= 0);

xcoord = xcoord(nondiscard_node);
ycoord = ycoord(nondiscard_node);

% renumbering
if ~isempty(discard_node)
    connd = conn(:);
    [connd, indx] = sort(connd);
    szc = size(connd);
    connd = diff(connd);
    connd(connd>0) = 1;
    connd = cumsum(connd)+1;
    connd = [1; connd];
    connd2 = zeros(szc);
    connd2(indx) = connd;
    clear connd;
    conn = reshape(connd2, size(conn));
    clear connd2;
end

clear elms0; clear qual;
clear nondiscard_elm;
clear discard_elm2; clear discard_elm3;
clear nondiscard_node; clear discard_node;

Nnode = length(ycoord);
Nelm = length(conn);
disp(['Nelement = ' sprintf('%d', Nelm)]);
disp(['Nnode = ' sprintf('%d', Nnode)]);
disp(' ');


%% ************************************************************************
% Find the center-of-mass points of elements
% *************************************************************************
center_x = (xcoord(conn(:,1)) + xcoord(conn(:,2)) + xcoord(conn(:,3)))/3;
center_y = (ycoord(conn(:,1)) + ycoord(conn(:,2)) + ycoord(conn(:,3)))/3;

%% ************************************************************************
% Find source boundary nodes
% *************************************************************************
[sourceb_node,d] = knnsearch([xcoord' ycoord'],[sourceb_x' sourceb_y'],'k',1);
sourceb_node = sort(unique(sourceb_node));

%% ************************************************************************
% Find PML boundary nodes
% *************************************************************************
[pmlb_node,d] = knnsearch([xcoord' ycoord'],[pmlb_x' pmlb_y'],'k',1);
pmlb_node = sort(unique(pmlb_node));

%% ************************************************************************
% Find VOI boundary nodes
% *************************************************************************
[voib_node,d] = knnsearch([xcoord' ycoord'],[voib_x' voib_y'],'k',1);
voib_node = sort(unique(voib_node));

%% ************************************************************************
% Find PML inside nodes
% *************************************************************************
INPO = inpolygon(xcoord, ycoord, pmlb_x, pmlb_y);
temp_node = find(INPO == 1);

nodes0 = ones(1,length(xcoord));
nodes0(temp_node) = 0;
pml_node = find(nodes0 == 1);
clear nodes0;

nodes = ones(1,Nnode);
nodes(pml_node) = 0;
nodes(pmlb_node) = 0;
inside_node = find(nodes == 1);

%% ************************************************************************
% Find PML inside elms
% *************************************************************************
INPO = inpolygon(center_x, center_y, pmlb_x, pmlb_y);
temp_elm = find(INPO == 1);

elms0 = ones(1,length(center_x));
elms0(temp_elm) = 0;
pml_elm = find(elms0 == 1);
clear elms0;

ispmlelm = zeros(1,Nelm);
ispmlelm(pml_elm) = 1;

%% ************************************************************************
% Plot results
% *************************************************************************
if plot_mesh
    figure; set(gcf,'Color',[1 1 1]);
    triplot(conn, xcoord, ycoord);
    set(gcf,'Color',[1 1 1]);
    xlabel('x (m)');
    ylabel('y (m)');
    axis equal tight
    
    hold on
    plot(xcoord(pmlb_node), ycoord(pmlb_node),'m.', 'LineWidth',1)
    plot(xcoord(voib_node), ycoord(voib_node),'k.', 'LineWidth',1)
    plot(xcoord(pml_node), ycoord(pml_node),'y.', 'LineWidth',1)
    plot(xcoord(sourceb_node), ycoord(sourceb_node),'r.', 'LineWidth',1)   
end

%%
[pmlb_x, pmlb_y] = refine_boundary(pmlb_x, pmlb_y, 30, 1);
[voib_x, voib_y] = refine_boundary(voib_x, voib_y, 30, 1);

meshstr = struct('xcoord',xcoord,'ycoord',ycoord,'conn',conn, ...
'pmlb_x',pmlb_x,'pmlb_y',pmlb_y,'voib_x',voib_x,'voib_y',voib_y,...
'pmldim',pmldim,'radiuspmlx',radiuspmlx,'radiuspmly',radiuspmly, ...
'voib_node',voib_node,'radiusvoix',radiusvoix,'radiusvoiy',radiusvoiy, ...
'delh',delh,'Nnode',Nnode,'Nelm',Nelm,'object',object,...
'ispmlelm',ispmlelm,'sourceb_node',sourceb_node, 'inside_node',inside_node,...
'pml_node', pml_node);

