function [Ae] = element_matrix_log(elm, k, epsr, meshstr)
% This function calculates the element matrix with LCPML-log method.
% Called in fem.m and fempar.m
%
% Copyright (C) 2022, Ozlem Ozgun
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%    
% Contact:
% Dr. Ozlem Ozgun
% email: ozgunozlem@gmail.com
% web: http://www.ee.hacettepe.edu.tr/~ozlem/

delh = meshstr.delh;
xc = meshstr.xcoord; yc = meshstr.ycoord; conn = meshstr.conn;

n1 = conn(elm,1); n2 = conn(elm,2); n3 = conn(elm,3);

xn1 = xc(n1); xn2 = xc(n2); xn3 = xc(n3);
yn1 = yc(n1); yn2 = yc(n2); yn3 = yc(n3);

% Integration of delNi*delNj term
delxdelpsi = xn2-xn1;
delxdelnu = xn3-xn1;
delydelpsi = yn2-yn1;
delydelnu = yn3-yn1;

J0 = [delxdelpsi delydelpsi; delxdelnu delydelnu]; %jacobian

% calculate delNidelpsi, delNidelnu, delNjdelpsi, delNjdelnu
delNijdelpsi = [-1 1 0];
delNijdelnu  = [-1 0 1];

%%
A2e = zeros(3,3); A1e = zeros(3,3);

psi = [1/3 0.6 0.2 0.2];
nu = [1/3 0.2 0.6 0.2];
gp = [1-psi-nu; psi; nu]';
gw = [-27/96 25/96 25/96 25/96]; % gauss weights


for ig = 1:length(gw)
    gwi = gw(ig);
    
    Ni1 = gp(ig,1); Ni2 = gp(ig,2); Ni3 = gp(ig,3);
    
    x = xn1*Ni1 + xn2*Ni2 + xn3*Ni3;
    y = yn1*Ni1 + yn2*Ni2 + yn3*Ni3;
        
    %%
    % Find increment along x and y for numerical derivative
    xv = [xn1 xn2 xn3 xn1];
    yv = [yn1 yn2 yn3 yn1];
    
    dstep = delh*2.5;
    
    % Find increment along x
    [xi,yi] = polyxpoly([x-dstep x+dstep],[y y],xv,yv,'unique');
    xi1 = xi(xi > x); xhr = abs(max(xi1)-x)/4;
    xi2 = xi(xi < x); xhl = abs(min(xi2)-x)/4;
    xh = min(xhr,xhl);
    
    % Find increment along y
    [xi,yi] = polyxpoly([x,x], [y-dstep y+dstep],xv,yv,'unique');
    yi1 = yi(yi > y); yhu = abs(max(yi1)-y)/4;
    yi2 = yi(yi < y); yhd = abs(min(yi2)-y)/4;
    yh = min(yhu,yhd);
    
    
    % Derivatve of function w.r.t. x and y
    [fnxp1, fnyp1] = evalfun(x+xh,y,meshstr);
    [fnxm1, fnym1] = evalfun(x-xh,y,meshstr);
    [fnxp1b, fnyp1b] = evalfun(x+2*xh,y,meshstr);
    [fnxm1b, fnym1b] = evalfun(x-2*xh,y,meshstr);
    dfnxdx = (fnxm1b-8*fnxm1+8*fnxp1-fnxp1b)/(12*xh);
    dfnydx = (fnym1b-8*fnym1+8*fnyp1-fnyp1b)/(12*xh);
    
    [fnxp2, fnyp2] = evalfun(x,y+yh,meshstr);
    [fnxm2, fnym2] = evalfun(x,y-yh,meshstr);
    [fnxp2b, fnyp2b] = evalfun(x,y+2*yh,meshstr);
    [fnxm2b, fnym2b] = evalfun(x,y-2*yh,meshstr);
    dfnxdy = (fnxm2b-8*fnxm2+8*fnxp2-fnxp2b)/(12*yh);
    dfnydy = (fnym2b-8*fnym2+8*fnyp2-fnyp2b)/(12*yh);
        
    delxtdelx = 1+dfnxdx/(1j*k);
    delytdely = 1+dfnydy/(1j*k);
    delxtdely = dfnxdy/(1j*k);
    delytdelx = dfnydx/(1j*k);
    
    J2 = [delxtdelx delytdelx; delxtdely delytdely];
    J = J0*J2;
    Jinv = inv(J);
    Jdet = det(J);
    
    Jinv11 = Jinv(1,1); Jinv12 = Jinv(1,2); Jinv21 = Jinv(2,1); Jinv22 = Jinv(2,2);
    
    for i = 1:3
        Ni = gp(ig, i);
        
        for j = 1:3
            Nj = gp(ig, j);
            
            A2e(i,j) = A2e(i,j) + gwi*Ni*Nj*Jdet;
            
            A1e(i,j) = A1e(i,j) + gwi*((Jinv11.*delNijdelpsi(i)+Jinv12.*delNijdelnu(i)).* ...
                                       (Jinv11.*delNijdelpsi(j)+Jinv12.*delNijdelnu(j))+ ...
                                       (Jinv21.*delNijdelpsi(i)+Jinv22.*delNijdelnu(i)).* ...
                                       (Jinv21.*delNijdelpsi(j)+Jinv22.*delNijdelnu(j)))*Jdet;
        end
    end
end

Ae = A1e - A2e.*k^2 * epsr;

