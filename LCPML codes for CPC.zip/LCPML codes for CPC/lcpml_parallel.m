function [xc, yc] = lcpml_parallel(x, y, k, pmlbin_x, pmlbin_y, pmlbout_x, pmlbout_y)
% Parallelized version of the Original Locally-Conformal PML method
% Called in fempar.m
%
% INPUT:
% x,y: real coordinates (each is a row vector of PML points)
% k: wavenumber
% pmlbin_x, pmlbin_y: coordinates of the points on the inner PML boundary
% pmlbout_x, pmlbout_y: coordinates of the points on the outer PML boundary
% OUTPUT:
% xc, yc: complex coordinates (each is a row vector of PML points)
%
% Copyright (C) 2022, Ozlem Ozgun
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%    
% Contact:
% Dr. Ozlem Ozgun
% email: ozgunozlem@gmail.com
% web: http://www.ee.hacettepe.edu.tr/~ozlem/

approach = 0; % 0: set alpha manually, 1: set alpha automatically

% LC-PML parameters
m = 2;   % PML decay rate, integer 2 or 3
if approach == 0
    alpha = 15.0*k;
    alphajk = alpha/(1j*k);
end
 
% find the point on the inner PML boundary which is nearest to point P
xmat = gpuArray(repmat(x,length(pmlbin_x),1));
ymat = gpuArray(repmat(y,length(pmlbin_x),1));
pmlbin_xmat = gpuArray(repmat(pmlbin_x.',1,length(x)));
pmlbin_ymat = gpuArray(repmat(pmlbin_y.',1,length(x)));

[ksi,ind] = min(sqrt((pmlbin_xmat-xmat).^2+(pmlbin_ymat-ymat).^2));
x0 = pmlbin_x(ind);
y0 = pmlbin_y(ind);

clear xmat; clear ymat; clear pmlbin_xmat; clear pmlbin_ymat;
 
% find the point on the outer PML boundary in the direction of the unit vector
x0mat = gpuArray(repmat(x0,length(pmlbout_x),1));
y0mat = gpuArray(repmat(y0,length(pmlbout_x),1));
pmlbout_xmat = gpuArray(repmat(pmlbout_x.',1,length(x0)));
pmlbout_ymat = gpuArray(repmat(pmlbout_y.',1,length(x0)));

vpx = pmlbout_xmat-x0mat;
vpy = pmlbout_ymat-y0mat;
lp = sqrt(vpx.^2 + vpy.^2);
npx = vpx ./ lp; % unit vector from r0 to r1 (x-comp)
npy = vpy ./ lp; % unit vector from r0 to r1 (y-comp)

clear x0mat; clear y0mat; clear pmlbout_xmat; clear pmlbout_ymat;

vx = x-x0;
vy = y-y0;
l = sqrt(vx.^2 + vy.^2);
nx = vx ./ l; % unit vector from r0 to r (x-comp)
ny = vy ./ l; % unit vector from r0 to r (y-comp)

nxmat = gpuArray(repmat(nx,length(pmlbout_x),1));
nymat = gpuArray(repmat(ny,length(pmlbout_x),1));

[~,ind] = min(acos(complex(nxmat.*npx+nymat.*npy)));
x1 = pmlbout_x(ind);
y1 = pmlbout_y(ind);

clear nxmat; clear nymat;

% local PML thickness, distance btw P0 and P1
dpml = sqrt((x1-x0).^2+(y1-y0).^2);

if approach == 1
    alpha = -log(1e-2)*m./dpml;
    alphajk = alpha/(1j*k);
end

term = alphajk.*((ksi.^m) ./ (m*(dpml.^(m-1))));

% complex coordinates
xc = x + term.*nx;
yc = y + term.*ny;

ind = find(l<1e-8);
xc(ind) = x(ind);
yc(ind) = y(ind);
