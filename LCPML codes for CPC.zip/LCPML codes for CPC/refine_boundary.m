function [bxnew, bynew] = refine_boundary(bx, by, num, flag)
% It refines the boundary points.
% Called in meshgen files.
% if flag = 1, closed loop (refine btw first and last points),
% if flag = 2, open loop
%
% Copyright (C) 2022, Ozlem Ozgun
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%    
% Contact:
% Dr. Ozlem Ozgun
% email: ozgunozlem@gmail.com
% web: http://www.ee.hacettepe.edu.tr/~ozlem/

bxnew(1) = bx(1);
bynew(1) = by(1);
for i=1:length(bx)-1
    x = linspace(bx(i), bx(i+1), num);
    y = linspace(by(i), by(i+1), num);  
    
    bxnew = cat(2, bxnew, x(2:end));
    bynew = cat(2, bynew, y(2:end));    
end

if flag == 1
    x = linspace(bx(end), bx(1), num);
    y = linspace(by(end), by(1), num);  
    
    bxnew = cat(2, bxnew, x(2:end));
    bynew = cat(2, bynew, y(2:end));        
end
