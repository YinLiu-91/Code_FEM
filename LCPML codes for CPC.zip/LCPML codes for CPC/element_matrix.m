function [Ae] = element_matrix(elm, x, y, conn, k, epsr)
% It calculates the element matrix with triangular element.
% Called in fem.m and fempar.m
%
% Copyright (C) 2022, Ozlem Ozgun
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%    
% Contact:
% Dr. Ozlem Ozgun
% email: ozgunozlem@gmail.com
% web: http://www.ee.hacettepe.edu.tr/~ozlem/

n1 = conn(elm,1);
n2 = conn(elm,2);
n3 = conn(elm,3);

xn1 = x(n1); xn2 = x(n2); xn3 = x(n3);
yn1 = y(n1); yn2 = y(n2); yn3 = y(n3);

% Integration of delNi*delNj term
delxdelpsi = xn2-xn1;
delxdelnu = xn3-xn1;
delydelpsi = yn2-yn1;
delydelnu = yn3-yn1;

Jdet = delxdelpsi*delydelnu-delxdelnu*delydelpsi; %determinant of jacobian
area = 0.5*Jdet;

% calculate the terms of inverse jacobian matrix
Jinv11 = delydelnu./Jdet;
Jinv12 = -delydelpsi./Jdet;
Jinv21 = -delxdelnu./Jdet;
Jinv22 = delxdelpsi./Jdet;

% calculate delNidelpsi, delNidelnu, delNjdelpsi, delNjdelnu
delNijdelpsi = [-1 1 0];
delNijdelnu  = [-1 0 1];

gw = [1/6 1/6 1/6];  % gauss weights
gp = [0.5 0.5 0.0; 0.0 0.5 0.5; 0.5 0.0 0.5]; % gauss points

A1e = zeros(3,3);
A2e = zeros(3,3);

for i = 1:3   
    for j = i:3
        A1e(i,j)=((Jinv11.*delNijdelpsi(i)+Jinv12.*delNijdelnu(i)).* ...
                  (Jinv11.*delNijdelpsi(j)+Jinv12.*delNijdelnu(j))+ ...
                  (Jinv21.*delNijdelpsi(i)+Jinv22.*delNijdelnu(i)).* ...
                  (Jinv21.*delNijdelpsi(j)+Jinv22.*delNijdelnu(j)))*area;
        A1e(j,i) = A1e(i,j);
        
        sumg = 0;
        for ig = 1:length(gw)
            gwi = gw(ig);
            Ni = gp(ig, i);
            Nj = gp(ig, j);
            
            sumg = sumg+gwi*Ni*Nj*Jdet;
        end
        
        A2e(i,j) = sumg;
        A2e(j,i) = A2e(i,j);        
    end
end

Ae = A1e - A2e.*k^2*epsr;
