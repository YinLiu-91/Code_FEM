function [fnx, fny] = evalfun(xe,ye,meshstr)
% If evaluates the function at (xe, ye).
% It uses Lagrange multiplier method for circle and ellipse.
% Called in element_matrix_log.m
%
% Copyright (C) 2022, Ozlem Ozgun
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%    
% Contact:
% Dr. Ozlem Ozgun
% email: ozgunozlem@gmail.com
% web: http://www.ee.hacettepe.edu.tr/~ozlem/

object = meshstr.object;
rinx = meshstr.radiuspmlx; riny = meshstr.radiuspmly;
routx = meshstr.radiusvoix; routy = meshstr.radiusvoiy;

if strcmp(object,'circle') || strcmp(object,'ellipse')
    funi = @(lambda) abs((rinx^2*xe^2/(rinx^2-lambda)^2) + (riny^2*ye^2/(riny^2-lambda)^2) -1);
    lambdai0 = [-0.025];
    
    lambdai = fminsearch(funi,lambdai0);
    
    xin = xe/(1-lambdai/rinx^2);
    yin = ye/(1-lambdai/riny^2);
    
    funo = @(lambda) abs((lambda*xe-xin*(lambda-1))^2/routx^2 + (lambda*ye-yin*(lambda-1))^2/routy^2 -1);
    lambdao0 = [2];
    
    lambdao = fminsearch(funo,lambdao0);
    
    xout = lambdao*xe-xin*(lambdao-1);
    yout = lambdao*ye-yin*(lambdao-1);
    
elseif strcmp(object,'rectangle')
    if (xe >= rinx) && (ye >= -riny) && (ye <= riny) % Region 1
        xin = rinx; yin = ye;
        xout = routx; yout = ye;
        
    elseif (ye >= riny) && (xe >= -rinx) && (xe <= rinx) % Region 2
        xin = xe; yin = riny;
        xout = xe; yout = routy;
        
    elseif (xe <= -rinx) && (ye >= -riny) && (ye <= riny) % Region 3
        xin = -rinx; yin = ye;
        xout = -routx; yout = ye;
        
    elseif (ye <= -riny) && (xe >= -rinx) && (xe <= rinx) % Region 4
        xin = xe; yin = -riny;
        xout = xe; yout = -routy;
        
    elseif (xe > rinx) && (ye > riny)  % Regions 12 and 21
        xin = rinx; yin = riny;
        m = (ye-yin)/(xe-xin);
        
        if (ye <= ((routy-riny)/(routx-rinx))*(xe-xin)+yin) % R12
            xout = routx; yout = m*(xout-xin)+yin;
        else %R21
            yout = routy; xout = (1/m)*(yout-yin)+xin;
        end
        
    elseif (xe < -rinx) && (ye > riny) % Regions 23 and 32
        xin = -rinx; yin = riny;
        m = (ye-yin)/(xe-xin);
        
        if (ye <= ((routy-riny)/(-routx+rinx))*(xe-xin)+yin) % R32
            xout = -routx; yout = m*(xout-xin)+yin;
        else % R23
            yout = routy; xout = (1/m)*(yout-yin)+xin;
        end
        
    elseif (xe > rinx) && (ye < -riny) % Region 14 and 41
        xin = rinx; yin = -riny;
        m = (ye-yin)/(xe-xin);
        
        if (ye >= ((-routy+riny)/(routx-rinx))*(xe-xin)+yin) % R14
            xout = routx; yout = m*(xout-xin)+yin;
        else
            yout = -routy; xout = (1/m)*(yout-yin)+xin; % R41
        end
        
    elseif (xe < -rinx) && (ye < -riny) % Regions 34 and 43
        xin = -rinx; yin = -riny;
        m = (ye-yin)/(xe-xin);
        
        if (ye >= ((-routy+riny)/(-routx+rinx))*(xe-xin)+yin)
            xout = -routx; yout = m*(xout-xin)+yin; % R34
        else
            yout = -routy; xout = (1/m)*(yout-yin)+xin; % R43
        end
        
    end
end

%%
vx = xe-xin;
vy = ye-yin;
l = sqrt(vx.^2 + vy.^2);
nx = vx ./ l; % unit vector from r0 to r (x-comp)
ny = vy ./ l; % unit vector from r0 to r (y-comp)

dpml = sqrt((xout-xin)^2+(yout-yin)^2); % local PML thickness
r = ((xe - xin)^2 + (ye - yin)^2)^(1/2);
ksi = r / dpml;
f = -log(1-ksi);

fnx = f*nx;
fny = f*ny;

