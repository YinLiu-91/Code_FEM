function meshstr = meshgen_rectangle(xdim,ydim,delh,Nlayer,scx,scy)
% Mesh generation function for Rectangle using triangular elements
% Called in fem.m and fempar.m
%
% Copyright (C) 2022, Ozlem Ozgun
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%    
% Contact:
% Dr. Ozlem Ozgun
% email: ozgunozlem@gmail.com
% web: http://www.ee.hacettepe.edu.tr/~ozlem/

%% ************************************************************************
% Definition of input parameters
% ***********************************************************************
object = 'rectangle';
plot_mesh = 0;

pmlmax_x = xdim;
pmlmin_x = -xdim;
pmlmax_y = ydim;
pmlmin_y = -ydim;

pmldim = Nlayer*delh;  % PML distance away from the scatterer

% radiuspmlx = pmlmax_x;  
% radiuspmly = pmlmax_y;  

voimax_x = xdim+pmldim;
voimin_x = -xdim-pmldim;
voimax_y = ydim+pmldim;
voimin_y = -ydim-pmldim;

% radiusvoix = voimax_x;  
% radiusvoiy = voimax_y;  

radiussc = 2*delh; % region around source


%% ************************************************************************
% Boundary of circle for source
% *************************************************************************
delhs = delh / 1;
alfac = 2*asin(delhs*0.5/radiussc);
N = floor(1*pi/alfac);
Ni = 0:N;
alfai = 1*pi/N;
alfa = cat(2, alfai*Ni, -fliplr(alfai*Ni(2:end-1)));
      
sourceb_x = radiussc*cos(alfa) + scx;
sourceb_y = radiussc*sin(alfa) + scy;

%% ************************************************************************
% Outside of circle & Boundary of VOI
% *************************************************************************
npx = round(abs(pmlmax_x-pmlmin_x)/delh)+1;  % number of nodes along pml x
npy = round(abs(pmlmax_y-pmlmin_y)/delh)+1;  % number of nodes along pml y

nvx = round(pmldim/delh)+1;  % number of nodes along voi x
nvy = round(pmldim/delh)+1;  % number of nodes along voi y

tempx1 = linspace(voimin_x, pmlmin_x, nvx);
tempy1 = linspace(voimin_y, pmlmin_y, nvy);
tempx2 = linspace(pmlmin_x, pmlmax_x, npx);
tempy2 = linspace(pmlmin_y, pmlmax_y, npy);
tempx3 = linspace(pmlmax_x, voimax_x, nvx);
tempy3 = linspace(pmlmax_y, voimax_y, nvy);

tempx = [tempx1 tempx2(2:end-1) tempx3];
tempy = [tempy1 tempy2(2:end-1) tempy3];
  
[xarray, yarray] = meshgrid(tempx, tempy);
xat = xarray'; yat = yarray';
xcoord = xat(:)'; ycoord = yat(:)';
% clear tempx; clear tempy; 
clear xat; clear yat;

corners(1).coords = [tempx3' fliplr(tempy1)'];
corners(2).coords = [tempx3' tempy3'];
corners(3).coords = [fliplr(tempx1)' tempy3'];
corners(4).coords = [fliplr(tempx1)' fliplr(tempy1)'];


%%
threshold = delh * 0.8;
[discard,d] = knnsearch([xcoord' ycoord'],[sourceb_x' sourceb_y'],'k',40);
ind = find(d < threshold);
discard = unique(discard(ind));

nodes0 = 1:length(xcoord); 
nodes0(discard) = 0;
nondiscard = find(nodes0 ~= 0);

xcoord = xcoord(nondiscard);
ycoord = ycoord(nondiscard);

xcoord = cat(2, xcoord, sourceb_x);
ycoord = cat(2, ycoord, sourceb_y);
    
C = [];
for ii = 1:4
    [ID,~] = knnsearch([xcoord' ycoord'],[corners(ii).coords(:,1) corners(ii).coords(:,2)],'k',1);
    ID = sort(unique(ID));

    for ic = 1:length(ID)-1
        C = [C; [ID(ic:ic+1)']];
    end
end

%% ************************************************************************
% Create mesh 
% *************************************************************************
conn = delaunayTriangulation(xcoord', ycoord', C);

center_x = (xcoord(conn(:,1)) + xcoord(conn(:,2)) + xcoord(conn(:,3)))/3;
center_y = (ycoord(conn(:,1)) + ycoord(conn(:,2)) + ycoord(conn(:,3)))/3;

INPO = inpolygon(center_x, center_y, sourceb_x, sourceb_y);
discard_elm = find(INPO == 1);      
   
elms0 = 1:size(conn,1); 
elms0(discard_elm) = 0;
nondiscard_elm = find(elms0 ~= 0);

conn = conn(nondiscard_elm,:);

nodes = 1:length(xcoord);
nodes(conn(:,1)) = 0;
nodes(conn(:,2)) = 0;
nodes(conn(:,3)) = 0;
nondiscard_node = find(nodes == 0);
discard_node = find(nodes ~= 0);

xcoord = xcoord(nondiscard_node);
ycoord = ycoord(nondiscard_node);

% renumbering
if ~isempty(discard_node)
    connd = conn(:);
    [connd, indx] = sort(connd);
    szc = size(connd);
    connd = diff(connd);
    connd(connd>0) = 1;
    connd = cumsum(connd)+1;
    connd = [1; connd];
    connd2 = zeros(szc);
    connd2(indx) = connd;
    clear connd;
    conn = reshape(connd2, size(conn));
    clear connd2;
end

clear elms0; clear qual;
clear nondiscard_elm;
clear discard_elm2; clear discard_elm3; 
clear nondiscard_node; clear discard_node;

Nnode = length(ycoord);
Nelm = length(conn);
disp(['Nelement = ' sprintf('%d', Nelm)]);
disp(['Nnode = ' sprintf('%d', Nnode)]);
disp(' ');


%% ************************************************************************
% Find the center-of-mass points of elements
% *************************************************************************
center_x = (xcoord(conn(:,1)) + xcoord(conn(:,2)) + xcoord(conn(:,3)))/3;
center_y = (ycoord(conn(:,1)) + ycoord(conn(:,2)) + ycoord(conn(:,3)))/3;

%% ************************************************************************
% Find source boundary nodes
% *************************************************************************
[sourceb_node,d] = knnsearch([xcoord' ycoord'],[sourceb_x' sourceb_y'],'k',1);
sourceb_node = sort(unique(sourceb_node));

%% ************************************************************************
% Find PML boundary nodes
% *************************************************************************
pmlb_node = find(((xcoord < pmlmax_x+1e-8) & (xcoord > pmlmax_x-1e-8) & ...
                  (ycoord < pmlmax_y+1e-8) & (ycoord > pmlmin_y-1e-8)) | ...
                 ((xcoord < pmlmin_x+1e-8) & (xcoord > pmlmin_x-1e-8) & ...
                  (ycoord < pmlmax_y+1e-8) & (ycoord > pmlmin_y-1e-8)) | ...
                 ((ycoord < pmlmax_y+1e-8) & (ycoord > pmlmax_y-1e-8) & ...
                  (xcoord < pmlmax_x+1e-8) & (xcoord > pmlmin_x-1e-8)) | ...
                 ((ycoord < pmlmin_y+1e-8) & (ycoord > pmlmin_y-1e-8) & ...
                  (xcoord < pmlmax_x+1e-8) & (xcoord > pmlmin_x-1e-8)));

pmlb_x = xcoord(pmlb_node);
pmlb_y = ycoord(pmlb_node);
   
ang = atan2(pmlb_y-0, pmlb_x-0);
[~, order] = sort(ang, 'descend');
pmlb_x = pmlb_x(order);
pmlb_y = pmlb_y(order);
pmlb_node = pmlb_node(order);

%% ************************************************************************
% Find VOI boundary nodes
% *************************************************************************
voib_node = find(((xcoord < voimax_x+1e-8) & (xcoord > voimax_x-1e-8)) | ...
                 ((xcoord < voimin_x+1e-8) & (xcoord > voimin_x-1e-8)) | ...
                 ((ycoord < voimax_y+1e-8) & (ycoord > voimax_y-1e-8)) | ...
                 ((ycoord < voimin_y+1e-8) & (ycoord > voimin_y-1e-8)));

voib_x = xcoord(voib_node);
voib_y = ycoord(voib_node);
    
ang = atan2(voib_y-0, voib_x-0);
[~, order] = sort(ang, 'descend');
voib_x = voib_x(order);
voib_y = voib_y(order);
voib_node = voib_node(order);

radiusvoix = max(voib_x); % meter, the radius of circle
radiusvoiy = max(voib_y);  % meter, the radius of circle
radiuspmlx = max(pmlb_x); % meter, the radius of circle
radiuspmly = max(pmlb_y);  % meter, the radius of circle

%% ************************************************************************
% Find PML inside nodes
% *************************************************************************
INPO = inpolygon(xcoord, ycoord, pmlb_x, pmlb_y);
temp_node = find(INPO == 1);      

nodes0 = ones(1,length(xcoord)); 
nodes0(temp_node) = 0;
pml_node = find(nodes0 == 1);
clear nodes0;

nodes = ones(1,Nnode);
nodes(pml_node) = 0;
nodes(pmlb_node) = 0;
inside_node = find(nodes == 1);

%% ************************************************************************
% Find PML inside elms
% *************************************************************************
INPO = inpolygon(center_x, center_y, pmlb_x, pmlb_y);
temp_elm = find(INPO == 1);      

elms0 = ones(1,length(center_x)); 
elms0(temp_elm) = 0;
pml_elm = find(elms0 == 1);
clear elms0;

ispmlelm = zeros(1,Nelm);
ispmlelm(pml_elm) = 1;

%% ************************************************************************
% Plot results
% *************************************************************************
if plot_mesh
    figure; set(gcf,'Color',[1 1 1]);
    triplot(conn, xcoord, ycoord);
    set(gcf,'Color',[1 1 1]);
    xlabel('x (m)');
    ylabel('y (m)');
    axis equal tight
    
    hold on
    plot(xcoord(pmlb_node), ycoord(pmlb_node),'m.', 'LineWidth',1)
    plot(xcoord(voib_node), ycoord(voib_node),'k.', 'LineWidth',1)
    plot(xcoord(pml_node), ycoord(pml_node),'y.', 'LineWidth',1)
    plot(xcoord(sourceb_node), ycoord(sourceb_node),'r.', 'LineWidth',1)
end

%%
[pmlb_x, pmlb_y] = refine_boundary(pmlb_x, pmlb_y, 30, 1);
[voib_x, voib_y] = refine_boundary(voib_x, voib_y, 30, 1);

meshstr = struct('xcoord',xcoord,'ycoord',ycoord,'conn',conn, ...
'pmlb_x',pmlb_x,'pmlb_y',pmlb_y,'voib_x',voib_x,'voib_y',voib_y,...
'radiuspmlx',radiuspmlx,'radiuspmly',radiuspmly, ...
'voib_node',voib_node,'radiusvoix',radiusvoix,'radiusvoiy',radiusvoiy, ...
'delh',delh,'Nnode',Nnode,'Nelm',Nelm,'object',object,...
'ispmlelm',ispmlelm,'sourceb_node',sourceb_node, 'inside_node',inside_node,...
'pml_node', pml_node);