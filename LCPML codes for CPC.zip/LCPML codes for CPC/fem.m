%% Name: fem.m (MAIN PROGRAM)
% It solves the 2D Helmholtz equation by using Finite Element Method 
% with linear triangular elements.
% It implements LCPML and LCPML-log methods.
%
% Use "method" and "objectID" variables to simulate different problems.
%
% Copyright (C) 2022, Ozlem Ozgun
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%    
% Contact:
% Dr. Ozlem Ozgun
% email: ozgunozlem@gmail.com
% web: http://www.ee.hacettepe.edu.tr/~ozlem/

clear;  close all;
tic

disp('**************************');
disp('FINITE ELEMENT METHOD (2D)');
disp('by Ozlem Ozgun');
disp('**************************');
disp('  ');

%% ***********************************************************************
% Definition of the constants
% ***********************************************************************
c0   = 3*1e8;           % m/sec, velocity of light in free space
nu0  = 120*pi;          % ohm, intrinsic impedance of the free space
eps0 = (1e-9)/(36*pi);  % F/m, permittivity
mu0  = 4*pi*1e-7;       % H/m, permeability of free space

%% ***********************************************************************
% Definition of input parameters 
% ***********************************************************************
lambda = 1;           % meter, wavelength
k      = 2*pi/lambda; % 1/meter, wavenumber
omg    = k*c0;        % radial frequency 
freq   = c0/lambda;   % Hz, frequency

method = 1;   % 0: Original LCPML, 1: LCPML-log 
objectID = 1; % 1: circle, 2: ellipse, 3: rectangle

% source location
scx = 0.2; scy = 0;

% Mesh generation 
switch objectID
    case 1
        object = 'circle';
        radiuspml = 1;   % meter, the radius of circle
        delh = 0.05/2;   % meter, the size of increment
        Nlayer = 1;      % Number of PML layers
        meshstr = meshgen_circle(radiuspml,delh,Nlayer,scx,scy);
        
    case 2
        object = 'ellipse';
        radiuspml = 2;   % meter, the radius of circle
        ec = sqrt(0.75); % eccentricity
        delh = 0.05/2;   % meter, the size of increment
        Nlayer = 1;      % Number of PML layers
        meshstr = meshgen_ellipse(radiuspml,ec,delh,Nlayer,scx,scy);
        
    case 3
        object = 'rectangle';
        xdim = 1;        % meter, half length along x
        ydim = 1;        % meter, half length along y
        delh = 0.05/2;   % meter, the size of increment
        Nlayer = 1;      % Number of PML layers
        meshstr = meshgen_rectangle(xdim,ydim,delh,Nlayer,scx,scy);
        
    otherwise
        disp('Check objectID !')
end

% load mesh data
Nnode = meshstr.Nnode; Nelm = meshstr.Nelm; conn = meshstr.conn;
names = fieldnames(meshstr);
for i=1:length(names)
    eval([names{i} '=meshstr.' names{i} ';' ]);
end

%% ************************************************************************
% Implement original LCPML if method == 0
% Original LCPML produces complex-valued coordinates
% *************************************************************************
if method == 0
    xcoordc = xcoord; ycoordc = ycoord;
    for i = 1:length(pml_node)
        in = pml_node(i);
        [xcoordc(in), ycoordc(in)] = lcpml(xcoord(in), ycoord(in), k, pmlb_x, pmlb_y, voib_x, voib_y);
    end
end

%% ************************************************************************
% MAIN BODY
% *************************************************************************
% initialize & construct the arrays
A = sparse(Nnode, Nnode); % A global matrix

epsrv = ones(1, Nelm); 

% construct element and global matrices
for e = 1:Nelm
    if mod(e,1000)==0
       disp(['Remaining # of elements < ' sprintf('%d', Nelm-e)]);
    end
   
    if ispmlelm(e) == 1 % If element is inside the PML region
        if method == 0 % with original LCPML
            Ae = element_matrix(e, xcoordc, ycoordc, conn, k, epsrv(e));
        elseif method == 1 % with LCPML-log
            Ae = element_matrix_log(e, k, epsrv(e), meshstr);
        end
    else
       Ae = element_matrix(e, xcoord, ycoord, conn, k, epsrv(e));        
    end
    
    % Global matrix assembly
    for i = 1:3
        ind1 = conn(e, i);
        for j = 1:3
            ind2 = conn(e, j);
            A(ind1, ind2) = A(ind1, ind2) + Ae(i, j);
        end
    end  
end    

% Impose boundary conditions
nodes = 1:Nnode;
nodes(voib_node) = 0;
nodes(sourceb_node) = 0;
othernodes = find(nodes ~= 0);
Atemp = speye(Nnode, Nnode);
Atemp(othernodes,:) = 0;
A(voib_node,:) = 0;
A(sourceb_node,:) = 0;
A = A+Atemp;

% Construct the right hand side vector
RHS = sparse(Nnode, 1);      % RHS of the final system of equations
rho = sqrt((xcoord(sourceb_node)-scx).^2 + (ycoord(sourceb_node)-scy).^2);
RHS(sourceb_node) = (1j/4.0)*besselh(0, 2, k*rho);               

disp('The matrix equation has been constructed!');

% Solve the matrix equation for the fields
field = (A\RHS).'; 

disp('The matrix equation has been solved!');
disp(' ');

%% ***********************************************************************
% POST-PROCESSING
%*************************************************************************
% Exact field
rhoe = sqrt((xcoord-scx).^2 + (ycoord-scy).^2);
fe = (1j/4.0)*besselh(0, 2, k*rhoe);

f1 = field(inside_node);
f0 = fe(inside_node);
errorMSE = norm(f1-f0)^2/norm(f0)^2;
disp(['errorMSE = ' sprintf('%.4e', errorMSE)]);

disp('THE END !');
time_elapsed = toc 
