#ifndef _GIT_LOG_MMG_H
#define _GIT_LOG_MMG_H
#define MMG_GIT_BRANCH "master"
#define MMG_GIT_COMMIT "71e46c5ba0a2345aefb32e523aafef7f0e71126e"
#define MMG_GIT_DATE   "2021-10-18 12:16:47 +0200"
#endif
