Program Name: 
------------
LCPML

Licensing Provisions:
--------------------
GNU General Public License 3

Program Description: 
-------------------
This program solves the 2D Helmholtz equation by using Finite Element Method with linear triangular elements.
It implements the LCPML and LCPML-log methods, which are described in the following paper to be published soon.
The developed MATLAB codes have been developed to perform the numerical examples in this paper.
The main codes are fem.m and fempar.m (fempar.m is the parallelized version of fem.m).

Paper Reference:
----------------
O. Ozgun, M. Kuzuoglu, H. Beriot, and R. Mittra, "Parametrization-Free Locally-Conformal Perfectly Matched Layer Method for Finite Element Solution of Helmholtz Equation," 2022.

Program Development:
-------------------
The program has been developed in MATLAB Release R2021a and tested on Windows 11.
Optimization Toolbox is required to run the LCPML-log method.
Parallel Computing Toolbox is required to run the parallelized version of the main program (fempar.m).

Description of Files/Subdirectories in the Main Directory: 
---------------------------------------------------------
fem.m   : Main file 
fempar.m: Main file (parallelized version)
element_matrix.m: It calculates the element matrix with triangular element. (Called in fem.m and fempar.m)
element_matrix_log.m: It calculates the element matrix with LCPML-log method. (Called in fem.m)
lcpml.m: It implements the original LCPML method. (Called in fem.m)
lcpml_parallel.m: Parallelized version of the original LCPML method. (Called in fempar.m)
evalfun.m: Called in element_matrix_log.m
meshgen_circle.m: Mesh generation function for circle using triangular elements. (Called in fem.m and fempar.m)
meshgen_ellipse.m: Mesh generation function for ellipse using triangular elements. (Called in fem.m and fempar.m)
meshgen_rectangle.m: Mesh generation function for rectangle using triangular elements. (Called in fem.m and fempar.m)
refine_boundary.m: Called in mesh generation functions.

Contact:
-------
You can send your questions, suggestions or bug reports to: 
Dr. Ozlem Ozgun
email: ozgunozlem@gmail.com
web: http://www.ee.hacettepe.edu.tr/~ozlem/ 
